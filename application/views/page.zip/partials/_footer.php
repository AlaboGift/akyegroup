<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style type="text/css">
    @media screen and (max-width: 320px){
     .desktop-footer,.hidden-nav{
        display: none;
     }
     .fix-bottom .container{
       z-index: 1;
       position: relative;
       left: -45px;
       margin-bottom:-35px;
       padding-bottom: 5px;
     }

     .container .user{ 
      z-index: 0;
      position: relative;
      top: -22px;
      right: -150px;
    }

    .feeter li{
     padding-top: 0px;
    }
    }

    @media screen and (max-width: 360px){
     .desktop-footer,.hidden-nav{
        display: none;
     }
     .fix-bottom .container{
       margin-left: -20px;
     }

    }

    @media screen and (max-width: 411px){
     .desktop-footer,.hidden-nav{
        display: none;
     }
     .fix-bottom .container{
       margin-left: -20px;
     }

    }

    @media screen and (max-width: 414px){
     .desktop-footer,.hidden-nav{
        display: none;
     }
     .fix-bottom .container{
       margin-left: -20px;
     }

    }

    @media screen and (max-width: 600px){
     .desktop-footer,.hidden-nav{
        display: none;
     }
     
    .scrollup{
        opacity: 0;
        margin-left:-10px;
     }

     .feeter li{
        display: inline;
        text-decoration: none;
        padding: 10px;
        margin-left: 15px;
        margin-right: 15px;
        position: relative;
        bottom: -10px;
        z-index: 1;
     }
     .sell-button{
        height: 10%;
        width: 20%;
        background-color: #3581ff;
        padding: 13px;
        z-index: 2;
        position: relative;
        top: -35px;
        border-radius: 50px;
        font-weight: bolder;
        color: #fff;
        font-size: 16px;
     }

     .fix-bottom{
        height: 5%;
        z-index: 0;
        position: relative;
        width: 100%;
     }

     .feeter li i{
        color: #fff;
        font-size: 20px;
    }

    
     .fa-home{
        color: black;
     }
    .fixed-bottom{
        padding: 0px;
    }
}
    @media screen and (min-width: 600px){
        .mobile-footer{
            display: none;
        }
    }

</style>
<footer id="footer">
    <div class="container desktop-footer">
        <div class="row">
            <div class="col-12">
                <div class="footer-top">
                    <div class="row">
                        <div class="col-12 col-md-3 footer-widget">
                            <div class="row-custom">
                                <div class="footer-logo">
                                    <a href="<?php echo base_url(); ?>"><img src="<?php echo get_logo($general_settings); ?>" alt="logo"></a>
                                </div>
                            </div>
                            <div class="row-custom">
                                <div class="footer-about">
                                    <?php echo html_escape($settings->about_footer); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-3 footer-widget">
                            <div class="nav-footer">
                                <div class="row-custom">
                                    <h4 class="footer-title"><?php echo trans("footer_quick_links"); ?></h4>
                                </div>
                                <div class="row-custom">
                                    <ul>
                                        <li><a href="<?php echo base_url(); ?>"><?php echo trans("home"); ?></a></li>
                                        <li><a href="<?php echo base_url(); ?>contact"><?php echo trans("contact"); ?></a></li>
                                        <?php foreach ($footer_quick_links as $item): ?>
                                            <li><a href="<?php echo base_url() . $item->slug; ?>"><?php echo html_escape($item->title); ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-3 footer-widget">
                            <div class="nav-footer">
                                <div class="row-custom">
                                    <h4 class="footer-title"><?php echo trans("footer_information"); ?></h4>
                                </div>
                                <div class="row-custom">
                                    <ul>
                                        <?php foreach ($footer_information_links as $item): ?>
                                            <li><a href="<?php echo base_url() . $item->slug; ?>"><?php echo html_escape($item->title); ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-3 footer-widget">
                            <div class="row-custom">
                                <h4 class="footer-title"><?php echo trans("follow_us"); ?></h4>
                                <div class="footer-social-links">
                                    <!--include social links-->
                                    <?php $this->load->view("partials/_social_links"); ?>
                                </div>
                            </div>
                            <div class="row-custom footer-location">
                                <div class="icon-text">
                                    <i class="icon-map-marker"></i>
                                    <?php echo trans("location"); ?>:
                                </div>
                                <?php
                                if ($general_settings->default_product_location != 0):?>
                                    <strong class="one-location-text"><?php echo $default_location; ?></strong>
                                <?php else: ?>
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                            <strong><?php echo $default_location; ?></strong>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="javascript:void(0)" onclick="set_default_location('all');"><?php echo trans("all"); ?></a>
                                            <?php if (!empty($countries)): foreach ($countries as $item): ?>
                                                <a class="dropdown-item" href="javascript:void(0)" onclick="set_default_location('<?php echo $item->id; ?>');"><?php echo html_escape($item->name); ?></a>
                                            <?php endforeach;
                                            endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid hidden-nav">
        <div class="row">
            <div class="footer-bottom">
                <div class="container">
                    <div class="copyright">
                        <?php echo html_escape($settings->copyright); ?>
                    </div>
                    <div class="payments">
                        <img src="<?php echo base_url(); ?>assets/img/payments.png" alt="payments" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="container mobile-footer fixed-bottom">
        <div class="fix-bottom">
        <?php if ($this->uri->segment(1)==""): ?>
        <?php if (auth_check() AND !is_service()): ?>
        <center><a href="<?php echo base_url(); ?>swap-now" class="sell-button">Swap Now &nbsp;<img src="<?=base_url()?>uploads/logo/camera.png" style="margin-top: -5px;"></a></center>
        <?php else: ?>
        <center><a href="javascript:void(0)" class="sell-button" data-toggle="modal" data-target="#loginModal">Swap Now &nbsp;<img src="<?=base_url()?>uploads/logo/camera.png" style="margin-top: -5px;"></a></center>
        <?php endif; ?>
        <?php endif; ?>
        </div>
    </div>
</footer>
<?php if (!isset($_COOKIE["modesy_cookies_warning"]) && $settings->cookies_warning): ?>
    <div class="cookies-warning">
        <div class="text"><?php echo $this->settings->cookies_warning_text; ?></div>
        <a href="javascript:void(0)" onclick="hide_cookies_warning();" class="icon-cl"> <i class="icon-close"></i></a>
    </div>
<?php endif; ?>
<!-- Scroll Up Link -->
<a href="javascript:void(0)" class="scrollup"><i class="icon-arrow-up"></i></a>

<script>
    var base_url = '<?php echo base_url(); ?>';
    var fb_app_id = '<?php echo $this->general_settings->facebook_app_id; ?>';
    var csfr_token_name = '<?php echo $this->security->get_csrf_token_name(); ?>';
    var csfr_cookie_name = '<?php echo $this->config->item('csrf_cookie_name'); ?>';
</script>
<!-- Popper JS-->
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/popper.min.js"></script>
<!-- Bootstrap JS-->
<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!-- Owl-carousel -->
<script src="<?php echo base_url(); ?>assets/vendor/owl-carousel/owl.carousel.min.js"></script>
<!-- Plugins JS-->
<script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
<!-- Custom JS-->
<?php $this->load->view("partials/_js_footer.min.php"); ?>
    <script src="<?php echo base_url(); ?>assets/js/choices.js"></script>
</body>
</html>