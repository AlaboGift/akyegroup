<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!-- Wrapper -->
<style type="text/css">
    @media screen and (max-width: 600px){
     .more{
        margin-bottom: 120px;
     }
 }
</style>

<div id="wrapper">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="index-title"><?php echo html_escape($settings->site_title); ?></h1>
                <?php if (!empty($slider_items) && $general_settings->index_slider == 1): ?>
                    <section class="section section-slider">
                        <!-- main slider -->
                        <?php $this->load->view("partials/_main_slider"); ?>
                    </section>
                <?php endif; ?>

                <?php if ($featured_category_count > 0 && $general_settings->index_categories == 1): ?>
                    <section class="section section-categories">
                        <!-- featured categories -->
                        <?php $this->load->view("partials/_featured_categories"); ?>
                    </section>
                <?php endif; ?>

                <div class="row-custom row-bn">
                 
                <div class="item">
                <a href="#">
                <img src="<?php echo base_url()?>uploads/slider/banner.jpg " class=".img-fluid" style="max-width: 100%;height: auto;" alt="slider">
                </a>
                </div>
                </div>

                <?php if ($general_settings->index_latest_products == 1 && !empty($products)): ?>
                    <section class="section section-latest-products">
                        
                        <div class="row">
                            <!--print products-->

                            <?php foreach ($products as $product): ?>
                                
                                <div class="col-6 col-sm-4 col-md-3">
                                    <?php $this->load->view('product/_product_item', ['product' => $product, 'promoted_badge' => false]); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="row-custom text-center more">
                            <a href="<?php echo base_url() . "products"; ?>" class="link-see-more"><span><?php echo trans("see_more"); ?>&nbsp;</span><i class="icon-arrow-right"></i></a>
                        </div>
                    </section>
                <?php endif; ?>

                <div class="row-custom row-bn">
                    <!--Include banner-->
                    <?php $this->load->view("partials/_ad_spaces", ["ad_space" => "index_2", "class" => ""]); ?>
                </div>
                <?php if ($general_settings->index_blog_slider == 1 && !empty($blog_slider_posts)): ?>
                    <section class="section section-blog m-0">
                        <h3 class="title"><?php echo trans("latest_blog_posts"); ?></h3>
                        <p class="title-exp"><?php echo trans("latest_blog_posts_exp"); ?></p>
                        <div class="row-custom">
                            <!-- main slider -->
                            <?php $this->load->view("blog/_blog_slider", ['blog_slider_posts' => $blog_slider_posts]); ?>
                        </div>
                    </section>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Wrapper End-->